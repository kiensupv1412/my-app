'use client';

import { TocPlugin } from '@udecode/plate-heading/react';

export const tocPlugin = TocPlugin.configure({
  options: {
    // isScroll: true,
    topOffset: 80,
  },
});
