'use client';

import { TablePlugin } from '@udecode/plate-table/react';

export const tablePlugin = TablePlugin.configure({
  options: {},
});
