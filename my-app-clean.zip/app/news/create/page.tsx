import NewsEditorPage from '@/components/news/NewsEditorPage';

export default function Page() {
  return <NewsEditorPage mode='create' />;
}
