'use client';

import {
  EquationPlugin,
  InlineEquationPlugin,
} from '@udecode/plate-math/react';

export const equationPlugins = [InlineEquationPlugin, EquationPlugin];
